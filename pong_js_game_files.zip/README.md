
This project was developed to help demonstrate code to potential software develompment students.
This JavaScript version of Pong is based on the javascript-pong repository found on github here: https://github.com/jakesgordon/javascript-pong/



